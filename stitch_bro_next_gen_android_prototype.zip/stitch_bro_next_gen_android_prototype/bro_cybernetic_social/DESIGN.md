---
name: BRO Cybernetic Social
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d2027'
  surface-container-high: '#272a32'
  surface-container-highest: '#32353d'
  on-surface: '#e0e2ec'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e0e2ec'
  inverse-on-surface: '#2d3038'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#deb7ff'
  on-secondary: '#4a007f'
  secondary-container: '#6b13af'
  on-secondary-container: '#d4a5ff'
  tertiary: '#daffde'
  on-tertiary: '#003919'
  tertiary-container: '#00f984'
  on-tertiary-container: '#006d36'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#f1dbff'
  secondary-fixed-dim: '#deb7ff'
  on-secondary-fixed: '#2d0050'
  on-secondary-fixed-variant: '#680eac'
  tertiary-fixed: '#60ff98'
  tertiary-fixed-dim: '#00e478'
  on-tertiary-fixed: '#00210c'
  on-tertiary-fixed-variant: '#005227'
  background: '#10131a'
  on-background: '#e0e2ec'
  surface-variant: '#32353d'
typography:
  headline-xl:
    fontFamily: Outfit
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Outfit
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Geist
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style
The design system establishes a hyper-refined, dark-first telepathic social canvas built around the pulse of immediate communication: TALK. CONNECT. EXIST. It targets digital natives and hyper-connected mobile operators who value velocity, tactile feedback, and sensory sophistication over cluttered social feeds.

The aesthetic fuses cybernetic minimalism with ambient glassmorphism. Surfaces are sculpted out of deep obsidian and vacuum blacks, lit only by high-frequency luminescent micro-currents. Interactions evoke the sensation of manipulating physical light guides and optic glass in zero gravity. The visual language avoids saturated novelty neon or tired cyberpunk dystopia; it embraces a pristine, calm, yet intensely charged digital realism—tactile, ergonomic, and frictionless for one-handed thumb navigation.

## Colors
The palette operates on calibrated light emission against low-reflectance spatial backdrops:

- **Primary (`#00F0FF` - Ion Cyan):** The primary focal driver. Used for direct interactions, critical touch targets, focused input rings, audio transmission waveforms, and active presence status.
- **Secondary (`#7B2CBF` - Electric Violet):** Atmospheric depth and relational affinity. Applied to room ambient backdrops, group interaction nodes, encryption confirmations, and secondary interactive states.
- **Tertiary (`#00FF87` - Neon Mint):** Biological and live telemetry. Reserved for active-now indicators, high-fidelity audio streams, ping latencies under 20ms, and verified connection nodes.
- **Neutral & Base Surfaces:** 
  - Canvas Root: `#090A0F` (Midnight Obsidian)
  - Surface Level 1 (Cards, elevated panels): `#0E1118` (Space Void)
  - Surface Level 2 (Floating glass sheets, sheets, bottom dock): `#161B26` (Atmospheric Slate)
  - Ghost Borders & Separators: `rgba(0, 240, 255, 0.12)` and `rgba(255, 255, 255, 0.08)`
  - Text Primary: `#F2F5F9` (98% contrast against canvas)
  - Text Secondary: `#8F9CAE` (Subtle cyber-metallic neutral)
  - Text Dim / Muted: `#4F5B6E`

## Typography
The typographic hierarchy relies on a dual-engine structure: **Outfit** acts as the dynamic architectural display face—geometric, self-assured, and broad—while **Geist** delivers crisp, monolinear mechanical legibility for dense streams, audio metadata, micro-counters, and fast-scrolling messaging channels.

- **Display & Section Headers:** High-tension negative letter-spacing gives headers a tight, cinematic voice without sacrificing instant visual digestion.
- **Labels & System Badges:** Set in `Geist` bold with positive tracking (`0.04em` to `0.08em`) to enforce legibility at tiny scale across real-time network statuses, audio hertz indicators, and message timestamps.
- **Body Text:** Neutral optical sizing optimized for OLED rendering with zero color-fringing against pitch-black backgrounds.

## Layout & Spacing
The layout architecture is optimized for modern high-density mobile viewports (baseline 390x844 dp) respecting Android gesture navigation insets, edge-to-edge rendering, and safe zones.

- **Rhythm & Grid:** Built on an absolute 4px/8px modular base rhythm. Screens utilize a fluid single-column chassis bounded by a fixed `1.25rem` (20px) horizontal safe margin to prevent thumb occlusion at device borders.
- **Vertical Ergonomics:** High-frequency targets are clamped within the thumb sweep arc (lower 60% of the viewport). Navigation, active audio toggles, and conversation dispatch are pinned or floated within comfortable downward reach.
- **Breakpoints:**
  - Mobile Base (`< 600px`): Single stream chassis, floating dynamic islands, and bottom sheet drawers.
  - Foldable / Unfolded (`600px - 840px`): Dual-pane split: left navigation + branch feed (320px fixed) with active conversation node dynamic canvas filling remainder.
  - Expanded / Tablet (`> 840px`): 12-column fluid grid, maximum content constraint of 1040px, centered.

## Elevation & Depth
Depth is articulated through optical luminosity rather than muddy drop shadows. The design system stacks dark semi-translucent glass layers accented by hairline photonic rims:

- **Level 0 (Root Space):** `#090A0F` flat absorbent void. No blur.
- **Level 1 (Conversation Branch Cards, Message Clusters):** Background `rgba(14, 17, 24, 0.75)` with `backdrop-filter: blur(16px)` and a continuous hairline outline: `1px solid rgba(255, 255, 255, 0.06)`.
- **Level 2 (Floating Action Docks, Bottom Navigation, Modals):** Background `rgba(22, 27, 38, 0.82)` with `backdrop-filter: blur(28px)`, a top-edge highlight (`1px solid rgba(0, 240, 255, 0.25)` blending down to `rgba(255, 255, 255, 0.04)`), and an ambient ground shadow: `0 16px 40px -8px rgba(0, 0, 0, 0.8), 0 0 24px -4px rgba(0, 240, 255, 0.08)`.
- **Level 3 (Popovers, Live Pings, Aura Pulses):** Glowing floating elements. Surface `#161B26` enveloped in a distinct directional cyan/violet luminescent aura: `0 0 32px 0 rgba(0, 240, 255, 0.22), 0 8px 24px 0 rgba(0, 0, 0, 0.9)`.

## Shapes
The shape philosophy favors aerodynamic capsules, softened hyper-rectangles, and organic circular nodes that evoke precision-machined physical hardware:

- **Buttons & Control Pills:** Full pill geometries (`border-radius: 9999px`) provide uninterrupted swipe vectors and effortless thumb accessibility.
- **Cards & Surface Nodes:** Substantial, ergonomic corners (`2rem` / `32px` on outer containers; `1.25rem` / `20px` on inner nested items) create clear visual grouping without visual harshness.
- **Presence Indicators & Avatars:** Absolute concentric circles with rhythmic pulsing aura gaps (2px gap ring using canvas color).

## Components

### Buttons
- **Primary Action (Hyper-Pill):** Solid `#00F0FF` background, text in deep `#090A0F` (`Geist` bold, uppercase tracking). Interactive states: subtle inner glow (`inset 0 1px 2px rgba(255,255,255,0.6)`) with press feedback scaling smoothly to `0.97`.
- **Secondary (Ghost Glass):** Transparent background with `1px solid rgba(0, 240, 255, 0.25)`, text `#F2F5F9`. Hover/press fills surface to `rgba(0, 240, 255, 0.08)`.
- **Tertiary / Destructive:** Muted dark base with crimson warning border `rgba(255, 75, 75, 0.3)` and `#FF5C5C` label.

### Navigation Dock & CREATE Orb
- **Bottom Navigation Bar:** Floating glass capsule suspended 16px above the home indicator. Background `rgba(14, 17, 24, 0.85)` with `24px` backdrop blur, encapsulated in a `1px` gradient border.
- **Center CREATE Action:** Elevated `56x56dp` circular orb protruding 12px above the dock bar line. Features a dual-gradient fill (`#00F0FF` to `#7B2CBF`) with a permanent, breathing ambient drop glow (`0 0 20px rgba(0, 240, 255, 0.4)`). An icon cross morphs seamlessly to an audio waveform on long-press.

### Conversation Branch Cards
- Rounded rectangular containers (`border-radius: 1.5rem`) styled in Level 1 glass.
- Top meta row contains active connection nodes, encryption protocol pills, and relative timestamps.
- Body displays snippet or live interactive voice waveforms.
- Lower edge features quick-swipe reaction pills and threaded response branches.

### Presence Status Indicators & Audio Waves
- **Live Emerald Aura Ping:** An 8px `#00FF87` dot with two concentric radiating SVG waves pulsing outward at 1.8s intervals with decaying opacity.
- **Live Audio Wave Ripple:** Multi-bar dynamic equalizer bars (2px width, rounded tips) animating vertically in `#00F0FF`, bounded within a mini pill container.
- **Live Counter Badges:** High-contrast pill (`#00F0FF` text on `rgba(0, 240, 255, 0.15)` fill, `1px solid rgba(0, 240, 255, 0.3)`).

### Input Fields
- Capsule and rounded container inputs (`border-radius: 1.25rem`), background `rgba(22, 27, 38, 0.6)`.
- Resting border `1px solid rgba(255, 255, 255, 0.08)`.
- Focused state transforms the border to an electric cyan trace (`1px solid #00F0FF`) with a micro-glow shadow (`0 0 12px rgba(0, 240, 255, 0.2)`). Placeholder rendered in `#4F5B6E`.
- Integrated inline voice toggle mic pill resting on the right-hand trailing boundary.

### Chips & Filter Pills
- Compact pills (`height: 32px`, `padding: 0 12px`) with `Geist label-md` typography.
- Active: `#00F0FF` text, `rgba(0, 240, 255, 0.12)` background, `1px solid #00F0FF`.
- Inactive: `#8F9CAE` text, `rgba(255, 255, 255, 0.03)` background, `1px solid rgba(255, 255, 255, 0.06)`.

### Selection Controls (Checkboxes & Radios)
- **Radio Nodes:** 20px outer glass ring with a glowing 8px `#00F0FF` center pip when selected.
- **Switches:** Cylindrical track (`height: 24px`, `width: 44px`) in dark charcoal; active thumb transitions to vibrant `#00FF87` with an expansive soft aura illumination.